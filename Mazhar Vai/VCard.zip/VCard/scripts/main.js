(function ($) {
	"use strict";


}(jQuery));